CRUD DE ESTUDIANTES - PYTHON MVC

Estructura:
- model/: contiene la lógica y datos de estudiantes.
- view/: contiene la interfaz gráfica.
- controller/: conecta el modelo con la vista.
- shared/: almacena los datos en JSON.
- main.py: ejecuta el sistema.

Requisitos:
- Python 3
- Tkinter (normalmente incluido con Python)

Ejecución:
1. Abrir esta carpeta en VS Code.
2. Abrir una terminal.
3. Ejecutar:
   python main.py

Operaciones:
- Crear estudiante
- Leer/listar estudiantes
- Buscar por cédula
- Editar estudiante
- Eliminar estudiante

También utiliza:
- Listas
- Tuplas
- Conjuntos
- Diccionarios
- JSON
- Patrón MVC
