import json
import os


class Estudiante:
    def __init__(self, cedula, nombre, apellido, edad, carrera):
        self.cedula = cedula
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad
        self.carrera = carrera

    def to_dict(self):
        return {
            "cedula": self.cedula,
            "nombre": self.nombre,
            "apellido": self.apellido,
            "edad": self.edad,
            "carrera": self.carrera
        }


class EstudianteModel:
    def __init__(self):
        self.archivo = "shared/estudiantes.json"
        self.estudiantes = []
        self.lista_estudiantes = []
        self.campos = ("cedula", "nombre", "apellido", "edad", "carrera")
        self.cedulas_registradas = set()
        self.datos_estudiante = {}
        self.cargar_datos()

    def agregar(self, estudiante):
        if estudiante.cedula in self.cedulas_registradas:
            return False

        self.estudiantes.append(estudiante)
        self.lista_estudiantes.append(estudiante)
        self.cedulas_registradas.add(estudiante.cedula)
        self.guardar_datos()
        return True

    def obtener_todos(self):
        return self.estudiantes

    def buscar(self, cedula):
        for estudiante in self.estudiantes:
            if estudiante.cedula == cedula:
                return estudiante
        return None

    def editar(self, cedula, nombre, apellido, edad, carrera):
        estudiante = self.buscar(cedula)
        if estudiante is None:
            return False

        estudiante.nombre = nombre
        estudiante.apellido = apellido
        estudiante.edad = edad
        estudiante.carrera = carrera
        self.guardar_datos()
        return True

    def eliminar(self, cedula):
        estudiante = self.buscar(cedula)
        if estudiante is None:
            return False

        self.estudiantes.remove(estudiante)
        self.lista_estudiantes.remove(estudiante)
        self.cedulas_registradas.discard(cedula)
        self.guardar_datos()
        return True

    def guardar_datos(self):
        os.makedirs("shared", exist_ok=True)
        datos = [estudiante.to_dict() for estudiante in self.estudiantes]

        with open(self.archivo, "w", encoding="utf-8") as archivo:
            json.dump(datos, archivo, indent=4, ensure_ascii=False)

    def cargar_datos(self):
        if not os.path.exists(self.archivo):
            return

        try:
            with open(self.archivo, "r", encoding="utf-8") as archivo:
                datos = json.load(archivo)

            for item in datos:
                estudiante = Estudiante(
                    item["cedula"],
                    item["nombre"],
                    item["apellido"],
                    item["edad"],
                    item["carrera"]
                )
                self.estudiantes.append(estudiante)
                self.lista_estudiantes.append(estudiante)
                self.cedulas_registradas.add(estudiante.cedula)

        except (json.JSONDecodeError, FileNotFoundError, KeyError):
            pass
