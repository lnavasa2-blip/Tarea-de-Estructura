import tkinter as tk

from model.estudiante_model import EstudianteModel
from view.estudiante_view import EstudianteView
from controller.estudiante_controller import EstudianteController


def main():
    root = tk.Tk()

    model = EstudianteModel()
    view = EstudianteView(root)
    controller = EstudianteController(model, view)

    view.boton_crear.config(command=controller.crear_estudiante)
    view.boton_buscar.config(command=controller.buscar_estudiante)
    view.boton_editar.config(command=controller.editar_estudiante)
    view.boton_eliminar.config(command=controller.eliminar_estudiante)
    view.boton_limpiar.config(command=view.limpiar)

    controller.mostrar_estudiantes()

    root.mainloop()


if __name__ == "__main__":
    main()
