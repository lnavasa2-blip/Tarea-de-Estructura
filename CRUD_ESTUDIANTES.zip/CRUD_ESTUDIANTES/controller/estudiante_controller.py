from model.estudiante_model import Estudiante


class EstudianteController:
    def __init__(self, model, view):
        self.model = model
        self.view = view

    def crear_estudiante(self):
        cedula = self.view.cedula.get().strip()
        nombre = self.view.nombre.get().strip()
        apellido = self.view.apellido.get().strip()
        edad = self.view.edad.get().strip()
        carrera = self.view.carrera.get().strip()

        if not all([cedula, nombre, apellido, edad, carrera]):
            self.view.mostrar_mensaje("Error", "Todos los campos son obligatorios.")
            return

        try:
            edad = int(edad)
            if edad <= 0:
                raise ValueError
        except ValueError:
            self.view.mostrar_mensaje("Error", "La edad debe ser un número positivo.")
            return

        estudiante = Estudiante(cedula, nombre, apellido, edad, carrera)

        if self.model.agregar(estudiante):
            self.view.mostrar_mensaje("Éxito", "Estudiante registrado correctamente.")
            self.view.limpiar()
            self.mostrar_estudiantes()
        else:
            self.view.mostrar_mensaje("Error", "La cédula ya está registrada.")

    def mostrar_estudiantes(self):
        self.view.mostrar_estudiantes(self.model.obtener_todos())

    def buscar_estudiante(self):
        cedula = self.view.cedula.get().strip()

        if not cedula:
            self.view.mostrar_mensaje("Error", "Ingrese la cédula.")
            return

        estudiante = self.model.buscar(cedula)

        if estudiante:
            self.view.nombre.delete(0, "end")
            self.view.nombre.insert(0, estudiante.nombre)
            self.view.apellido.delete(0, "end")
            self.view.apellido.insert(0, estudiante.apellido)
            self.view.edad.delete(0, "end")
            self.view.edad.insert(0, estudiante.edad)
            self.view.carrera.delete(0, "end")
            self.view.carrera.insert(0, estudiante.carrera)
        else:
            self.view.mostrar_mensaje("Buscar", "Estudiante no encontrado.")

    def editar_estudiante(self):
        cedula = self.view.cedula.get().strip()
        nombre = self.view.nombre.get().strip()
        apellido = self.view.apellido.get().strip()
        edad = self.view.edad.get().strip()
        carrera = self.view.carrera.get().strip()

        if not all([cedula, nombre, apellido, edad, carrera]):
            self.view.mostrar_mensaje("Error", "Todos los campos son obligatorios.")
            return

        try:
            edad = int(edad)
            if edad <= 0:
                raise ValueError
        except ValueError:
            self.view.mostrar_mensaje("Error", "La edad debe ser un número positivo.")
            return

        if self.model.editar(cedula, nombre, apellido, edad, carrera):
            self.view.mostrar_mensaje("Éxito", "Estudiante actualizado correctamente.")
            self.view.limpiar()
            self.mostrar_estudiantes()
        else:
            self.view.mostrar_mensaje("Error", "No se encontró el estudiante.")

    def eliminar_estudiante(self):
        cedula = self.view.cedula.get().strip()

        if not cedula:
            self.view.mostrar_mensaje("Error", "Ingrese la cédula.")
            return

        if self.model.eliminar(cedula):
            self.view.mostrar_mensaje("Éxito", "Estudiante eliminado correctamente.")
            self.view.limpiar()
            self.mostrar_estudiantes()
        else:
            self.view.mostrar_mensaje("Error", "No se encontró el estudiante.")
