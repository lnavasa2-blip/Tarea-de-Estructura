import tkinter as tk
from tkinter import ttk, messagebox


class EstudianteView:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema CRUD de Estudiantes")
        self.root.geometry("900x650")
        self.root.resizable(False, False)

        titulo = tk.Label(
            root,
            text="CRUD DE ESTUDIANTES",
            font=("Arial", 22, "bold")
        )
        titulo.pack(pady=15)

        formulario = tk.Frame(root)
        formulario.pack(pady=5)

        campos = [
            ("Cédula:", "cedula"),
            ("Nombre:", "nombre"),
            ("Apellido:", "apellido"),
            ("Edad:", "edad"),
            ("Carrera:", "carrera")
        ]

        for fila, (texto, atributo) in enumerate(campos):
            tk.Label(
                formulario,
                text=texto,
                font=("Arial", 10)
            ).grid(row=fila, column=0, padx=10, pady=7, sticky="e")

            entrada = tk.Entry(formulario, width=35)
            entrada.grid(row=fila, column=1, padx=10, pady=7)
            setattr(self, atributo, entrada)

        botones = tk.Frame(root)
        botones.pack(pady=15)

        self.boton_crear = tk.Button(botones, text="Crear", width=13)
        self.boton_crear.grid(row=0, column=0, padx=5)

        self.boton_buscar = tk.Button(botones, text="Buscar", width=13)
        self.boton_buscar.grid(row=0, column=1, padx=5)

        self.boton_editar = tk.Button(botones, text="Editar", width=13)
        self.boton_editar.grid(row=0, column=2, padx=5)

        self.boton_eliminar = tk.Button(botones, text="Eliminar", width=13)
        self.boton_eliminar.grid(row=0, column=3, padx=5)

        self.boton_limpiar = tk.Button(botones, text="Limpiar", width=13)
        self.boton_limpiar.grid(row=0, column=4, padx=5)

        columnas = ("cedula", "nombre", "apellido", "edad", "carrera")

        self.tabla = ttk.Treeview(
            root,
            columns=columnas,
            show="headings",
            height=12
        )

        encabezados = {
            "cedula": "Cédula",
            "nombre": "Nombre",
            "apellido": "Apellido",
            "edad": "Edad",
            "carrera": "Carrera"
        }

        anchos = {
            "cedula": 130,
            "nombre": 150,
            "apellido": 150,
            "edad": 70,
            "carrera": 250
        }

        for columna in columnas:
            self.tabla.heading(columna, text=encabezados[columna])
            self.tabla.column(columna, width=anchos[columna], anchor="center")

        self.tabla.pack(pady=10)

    def mostrar_estudiantes(self, estudiantes):
        for item in self.tabla.get_children():
            self.tabla.delete(item)

        for estudiante in estudiantes:
            self.tabla.insert(
                "",
                "end",
                values=(
                    estudiante.cedula,
                    estudiante.nombre,
                    estudiante.apellido,
                    estudiante.edad,
                    estudiante.carrera
                )
            )

    def limpiar(self):
        for campo in (
            self.cedula,
            self.nombre,
            self.apellido,
            self.edad,
            self.carrera
        ):
            campo.delete(0, "end")

    def mostrar_mensaje(self, titulo, mensaje):
        messagebox.showinfo(titulo, mensaje)
